var x = 50;
var y = 50;
var x1 = 100;
var y1 = 100;
var x2 = 200;
var y2 = 200;
var x1Move = Math.floor(Math.random() * 10);
var x2Move = Math.floor(Math.random() * 10);
var y1Move = Math.floor(Math.random() * 10);
var y2Move = Math.floor(Math.random() * 10);
var mousex = -10;
var mousey = -10;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  createExit();
  createPlayer();
  createObstacles();
  createMouseCircle();
  
  movePlayer();
  moveCircle1();
  moveCircle2();
}

function mouseClicked() {
  mousex = mouseX;
  mousey = mouseY;
}

function createMouseCircle(){
  fill('blue');
  ellipse(mousex, mousey, 15, 50);
}

function createPlayer(){
  fill(24, 200, 29);
  circle(x, y, 50);
}

function createExit(){
  fill('white');
  rect(400, 370, 70, 50);
  fill('black');
  textSize(20);
  text('EXIT', 413, 390);
}

function movePlayer(){
  if (keyIsDown(83) && y < 400) {
    y += 10;
  }
  else if (keyIsDown(87) && y > 0) {
    y -= 10;
  }
  
  if (keyIsDown(65) && x > 0) {
    x -= 10;
  }
  else if (keyIsDown(68) && x < 600) {
    x += 10;
  }
  
  if ((x >= 400 && x <= 470) && y >= 370){
    displayWin();
  }
}

function displayWin(){
  fill('white');
  textSize(100);
  text('YOU WIN!!!!', 25, 230);
}

function createObstacles(){
  fill('red');
  circle(x1, y1, 30);
  fill('orange');
  circle(x2, y2, 70);
}

function moveCircle1(){
  if(x1 >= 600){
    x1 = 1;
  }
  if(x1 <= 0){
    x1 = 599;
  }
  x1 -= x1Move;
  
  if(y1 >= 400){
    y1 = 1;
  }
  if(y1 <= 0){
    y1 = 399;
  }
  y1 += y1Move;
}

function moveCircle2(){
  if(x2 >= 600){
    x2 = 1;
  }
  if(x2 <= 0){
    x2 = 599;
  }
  x2 -= x1Move;
  
  if(y2 >= 400){
    y2 = 1;
  }
  if(y2 <= 0){
    y2 = 399;
  }
  y2 -= y2Move;
}